package com.oop.oop;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class Car{
    String color;
    String model;

    private int current_gear;



    public void stop(){
        Log.d("Car", "Enggine Stop");

    }

    public void start(){
        Log.d("Car", "Enggine Start");
    }

    public void changeGear(int gear){
        Log.d("Car", "Change Gear"+gear);
    }
}
