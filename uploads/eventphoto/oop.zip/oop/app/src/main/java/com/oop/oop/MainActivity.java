package com.oop.oop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Car myCar = new Car();
        Car yourCar = new Car();

        myCar.stop();
        myCar.start();
        myCar.changeGear(8);

    }
}
